﻿using Newtonsoft.Json;

public class Assets
{
    [JsonProperty("WEB")]
    public List<string> Web { get; set; }
}
