﻿namespace AlteredSearch.Models.Requests
{
    public class GetAllUniquesByFactionAndNameRequest
    {
        public string Faction { get; set; }

        public string Name { get; set; }
    }
}
